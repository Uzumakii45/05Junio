import pandas as pd

from data.generators.conteoarboles import ContadordeArboles
from helpers.crearTablaHTML import crearTabla
def contruirDataArbol():
    DataArbol = ContadordeArboles()

    RecolectorDato = pd.DataFrame(DataArbol,columns=['nombre', 'corregimiento', 'correo', 'fecha', 'hectareas_sembradas', 'especie_sembrada'])
    
    crearTabla(RecolectorDato,'Data_Arboles')
    print(RecolectorDato)
    
    RecolectorDato.replace('sin',pd.NA,inplace=True)
    #Elimino los registro que no cumplen con el criterio
    RecolectorDato.dropna(inplace=True)
    print(RecolectorDato)

contruirDataArbol()

