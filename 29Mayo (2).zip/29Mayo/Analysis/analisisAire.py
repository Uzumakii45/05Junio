import pandas as pd

from data.generators.generadorAire import  generarDatosCalidadAire
#se utliza crear tabla para generar una tabla y en el archivo rear tablahtml se jala 
from helpers.crearTablaHTML import crearTabla

def construirAireDataFrame():
    datosAire = generarDatosCalidadAire()  # Agregué paréntesis aquí

    aireDataFrame = pd.DataFrame(datosAire, columns=['comuna', 'comuna2', 'ica', 'fecba', 'correo'])

    #Generamos el recurso HTML
    crearTabla(aireDataFrame,'Datos Aire')
    #limpiando el dataframe
    #remplazando valores 
    aireDataFrame.replace('sin',pd.NA,inplace=True)
    #Elimino los registros que no cumplen el criterio 
    aireDataFrame.dropna(inplace=True)
    

    #Filtrar para que nos permita analizar datos de DF 
    
    filtroCalidadAireBueno=aireDataFrame.query("(ica>=10)and(ica<40)")
    filtroCalidadAireMedio=aireDataFrame.query("(ica>=40)and(ica<50)")
    filtroCalidadAireMalo=aireDataFrame.query("(ica>=50)and(ica<80)")
    print(filtroCalidadAireBueno)
    print('\n')
    print(filtroCalidadAireMedio)
    print('\n')
    print(filtroCalidadAireMalo)


construirAireDataFrame()