import pandas as pd
from data.contaminacionsonora import generarDatosContaminacionSonora
from helpers.crearTablaHTML import crearTabla

def GeneradorDatos():
    datos = generarDatosContaminacionSonora()
    df = pd.DataFrame(datos, columns=['nombre', 'comuna', 'correo','fecha','direccion','decibeliosdiurnos','decibeliosnocturnos'])
    
    crearTabla(df, 'Contaminacion_Sonora')
    print(df)

GeneradorDatos()