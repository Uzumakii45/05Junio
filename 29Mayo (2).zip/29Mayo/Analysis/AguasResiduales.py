import pandas as pd
from data.generators.M_AguasR import medicionAguasResiduales
from helpers.crearTablaHTML import crearTabla

def ConstruDataAgua():
    dataAgua = medicionAguasResiduales()
    
    AguasResiduales = pd.DataFrame(dataAgua, columns=['nombre','direccion','tipodefuente','composicionquimica'])
    
    crearTabla(AguasResiduales, 'Aguas_Residuales')
    print(AguasResiduales)

ConstruDataAgua()