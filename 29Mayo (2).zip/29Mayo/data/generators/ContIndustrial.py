import random

def ContaminacionIndustrial ():
    contaminacion = []
    for i in range(100):
        empresa = random.choice(['Grupo Éxito', 'Bancolombia', 'Ecopetrol', 'Grupo Sura', 'Avianca'])
        comuna = random.randint(1,14)
        fecha=random.choice(['2024-05-15','2024-05-16','sin'])
        correo=random.choice(['notiene@correo.com','notiene1@correo.com','notiene2@correo.com','notiene3@correo.com'])
        tipomuestra=random.choice(['Aire','Fuentes hidricas','Muestra de Hojas','Muestra Suelo',])
        encuesta=[empresa,comuna,fecha,correo,tipomuestra]
        contaminacion.append(encuesta)
        return contaminacion