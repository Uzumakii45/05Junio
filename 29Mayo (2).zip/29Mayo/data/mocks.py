#***** CALIDAD DEL AIRE ****#
#nombre
#comuna
#ICA
#fecha
#correo


#**** CONTAMINACION SONORA ****#
#nombre
#comuna
#direccion
#decibeliosdiurnos
#decibeliosnocturnos
#fecha


#*** SIEMBRA DEL ARBOLES ***#
#corregimiento
#hectareassembradas
#especiesembrada
#nombre
#fecha
#correo



#*** CONTAMINACIONA AGUAS RESITUALES ***#
#tipodefuente
#ubicacion
#composicionquimica
#contminacionxmetrocubicos
#nombre
#cantdAfectadas


#*** RECOLECCION DE RESIDUOS NO APROVECHABLES ***#
#ubicacion
#impactoambieltal
#fecharecolect
#residuosaprtoneladas
#residuosnoaprotoneladas


